package Main;

import Controller.SimulationManager;
import View.QueueView;

import java.util.ArrayList;

/**
 * Hello world!
 */
public class App 
{
    public static void main( String[] args ) throws InterruptedException {
        QueueView queueView = new QueueView();
    }
}

package Main.Exceptions;

public class ExceptionEmptyField extends Exception {
    public ExceptionEmptyField(String message) {
        super(message);
    }
}

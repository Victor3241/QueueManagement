package Main.Exceptions;

public class ExceptionMinHigherThanMax extends Exception {
    public ExceptionMinHigherThanMax(String message) {
        super(message);
    }
}
